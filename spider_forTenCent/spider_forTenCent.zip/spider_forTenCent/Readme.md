# BonesDL

This is a tool to get video(free and vip) from TencentVideo ,now version is V-beta0.2
i hope you will like it!

update log:
add save-functions
